package kristian.tugasakhir;

import android.media.MediaPlayer;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.MediaController;
import android.widget.TextView;
import android.widget.VideoView;

public class AlatKeselamatan extends AppCompatActivity
implements View.OnClickListener, MediaPlayer.OnPreparedListener {

    public Button btnNext, btnBack;
    public VideoView vidAnim;
    public TextView txDesk;

    public int jumlahVideo = 9;
    public int indVideo = 0;
    public int[] video = new int[jumlahVideo];
    public String[] deskripsi = new String[jumlahVideo];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.alat_keselamatan);

        video[0] = R.raw.helm;
        video[1] = R.raw.sabuk;
        video[2] = R.raw.sepatu;
        video[3] = R.raw.masker;
        video[4] = R.raw.sarungtangan;
        video[5] = R.raw.headphone;
        video[6] = R.raw.kacamata;
        video[7] = R.raw.jaket;
        video[8] = R.raw.allsafetykit;

        deskripsi[0] = getResources().getText(R.string.Helm).toString();
        deskripsi[1] = getResources().getText(R.string.Sabuk).toString();
        deskripsi[2] = getResources().getText(R.string.Sepatu).toString();
        deskripsi[3] = getResources().getText(R.string.Masker).toString();
        deskripsi[4] = getResources().getText(R.string.Sarung_Tangan).toString();
        deskripsi[5] = getResources().getText(R.string.Penutup_Telinga).toString();
        deskripsi[6] = getResources().getText(R.string.Kacamata_Pengaman).toString();
        deskripsi[7] = getResources().getText(R.string.Jaket).toString();
        deskripsi[8] = "Inilah alat-alat keselamatan yang harus digunakan";

        txDesk = (TextView) findViewById(R.id.txDesk);
        vidAnim = (VideoView) findViewById(R.id.vidAnim);
        btnNext = (Button) findViewById(R.id.btnNext);
        btnBack = (Button) findViewById(R.id.btnBack);

        btnNext.setOnClickListener(this);
        btnBack.setOnClickListener(this);

        btnBack.setEnabled(false);

        vidAnim.setMediaController(null);
        vidAnim.setOnPreparedListener(this);
        vidAnim.setVideoURI(Uri.parse("android.resource://" + getPackageName() + "/" +
                video[indVideo]));
        vidAnim.start();

        txDesk.setText(deskripsi[indVideo]);
    }

    @Override
    public void onClick(View view) {
        if(view.getId() == R.id.btnNext) {
            if(!btnNext.getText().toString().equals("FINISH")) {
                btnBack.setEnabled(true);

                indVideo++;

                if (indVideo < video.length) {
                    txDesk.setText(deskripsi[indVideo]);
                    vidAnim.stopPlayback();
                    vidAnim.setVideoURI(Uri.parse("android.resource://" + getPackageName() + "/" +
                            video[indVideo]));
                    vidAnim.start();

                    if (indVideo == video.length - 1) {
                        btnNext.setText("FINISH");
                    }
                } else {
                    indVideo = video.length - 1;
                }
            }
            else {
                finish();
            }
        }
        else if(view.getId() == R.id.btnBack) {
            btnNext.setEnabled(true);
            btnNext.setText("NEXT");

            indVideo--;

            if(indVideo >= 0) {
                txDesk.setText(deskripsi[indVideo]);
                vidAnim.stopPlayback();
                vidAnim.setVideoURI(Uri.parse("android.resource://" + getPackageName() + "/" +
                        video[indVideo]));
                vidAnim.start();

                if(indVideo == 0) {
                    btnBack.setEnabled(false);
                }
            }
            else {
                indVideo = 0;
            }
        }
    }

    @Override
    public void onPrepared(MediaPlayer mediaPlayer) {
        if(indVideo < video.length - 1) {
            mediaPlayer.setLooping(true);
            System.out.println(indVideo);
        }
        else {
            mediaPlayer.setLooping(false);
        }
    }
}
