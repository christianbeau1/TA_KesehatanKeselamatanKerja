package kristian.tugasakhir;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.*;

public class ActivityJenisKecelakaan extends AppCompatActivity
    implements View.OnClickListener {

    TextView txmateri, txjudul;
    Button btnNext, btnBack;

    String[] judulMateri = {"Migren", "Radiasi", "Sengatan Listrik", "Gempa"};
    String[] materi = new String[4];

    int iMateri = 0;
    int batasMateri = 4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_jenis_kecelakaan);

        txmateri = (TextView) findViewById(R.id.txmateri);
        txjudul = (TextView) findViewById(R.id.txjudul);
        btnNext = (Button) findViewById(R.id.btnnext);
        btnBack = (Button) findViewById(R.id.btnBack);

        btnNext.setOnClickListener(this);
        btnBack.setOnClickListener(this);

        btnBack.setEnabled(false);

        materi [0] = getResources().getText(R.string.Migren).toString();
        materi [1] = getResources().getText(R.string.Radiasi).toString();
        materi [2] = getResources().getText(R.string.Sengatan_Listrik).toString();
        materi [3] = getResources().getText(R.string.Gempa).toString();

        txmateri.setText(materi[iMateri]);
        txjudul.setText(judulMateri[iMateri]);
    }

    @Override
    public void onClick(View view) {
        if(view.getId() == R.id.btnnext) {
            if(!btnNext.getText().toString().equals("FINISH")) {
                btnBack.setEnabled(true);

                iMateri++;

                if (iMateri < materi.length) {
                    txmateri.setText(materi[iMateri]);
                    txjudul.setText(judulMateri[iMateri]);

                    if (iMateri == materi.length - 1) {
                        btnNext.setText("FINISH");
                    }
                } else {
                    iMateri = materi.length - 1;
                }
            }
            else {
                finish();
            }
        }
        else if(view.getId() == R.id.btnBack) {
            btnNext.setEnabled(true);
            btnNext.setText("NEXT");

            iMateri--;

            if(iMateri >= 0) {
                txmateri.setText(materi[iMateri]);
                txjudul.setText(judulMateri[iMateri]);

                if(iMateri == 0) {
                    btnBack.setEnabled(false);
                }
            }
            else {
                iMateri = 0;
            }
        }
    }
}
