package kristian.tugasakhir;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import java.util.ArrayList;

import android.view.View;
import android.widget.*;


public class MainActivity extends AppCompatActivity implements Button.OnClickListener{
    private Button btnjeniskecelakaan;

    private Managementdb db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnjeniskecelakaan = (Button) findViewById(R.id.btnjeniskecelakaan);
        btnjeniskecelakaan.setOnClickListener(this);

        db = Managementdb.dapatkanObjek(this);

        ArrayList<Managementdb.StrukturData> data =
                db.dapatkanSemuaData(Managementdb.TABEL_SOAL);
        for (int i = 0; i < data.size(); i++) {
            System.out.println("\n");
            System.out.println("TABELSOAL");
            System.out.println("id : " + data.get(i).dapatkanData(0));
            System.out.println("Soal : " + data.get(i).dapatkanData(1));
            System.out.println("A : " + data.get(i).dapatkanData(2));
            System.out.println("B : " + data.get(i).dapatkanData(3));
            System.out.println("C : " + data.get(i).dapatkanData(4));
            System.out.println("jawaban : " + data.get(i).dapatkanData(5));
        }
    }

    @Override
    public void onClick(View view) {
        if(view.getId() == R.id.btnjeniskecelakaan) {
            startActivity(new Intent(this, ActivityJenisKecelakaan.class));
        }
    }
}
