package kristian.tugasakhir; /**
 * Created by bulldog on 3/2/2018.
 */

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class Managementdb extends SQLiteOpenHelper {
    public final static String NAMADB = "db_tugasakhir";
    public final static String TABEL_SOAL = "tabel_soal";
    public final static String TABEL_ANIMASI = "tabel_animasi";

    private Context cont;
    private SQLiteDatabase db;
    private static Managementdb objek;

    private Managementdb(Context cont) {
        super(cont, NAMADB, null,1);
        this.cont = cont;
        this.objek = null;
    }

    public static Managementdb dapatkanObjek(Context cont) {
        if (objek == null) {
            objek = new Managementdb(cont);
            objek.buka();
        }
        return objek;
    }

    public void buka(){
        try{
            db = getWritableDatabase();
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    public void tutup() {
        if(db.isOpen()) {
            db.close();
        }
    }
    public boolean apakahpenuh (String namaTabel) {
        Cursor kur = db.rawQuery("select * from " + namaTabel, null);

        return (kur.getCount() > 0);

    }
    public void input(String namaTabel, StrukturData data) {
        Cursor kur = db.rawQuery ("select * from " + namaTabel, null);
        ContentValues val = new ContentValues();
        for (int i = 1; i < kur.getColumnCount(); i++) {
            val.put(kur.getColumnName(i), data.dapatkanData(i));
        }
        db.insert(namaTabel, null, val);
    }
    public ArrayList<StrukturData> dapatkanSemuaData(String namaTabel) {
        ArrayList<StrukturData> data = new ArrayList<>();

        Cursor kur = db.rawQuery("select * from " + namaTabel, null);

        kur.moveToFirst();

        int jumlahField = kur.getColumnCount();

        while(!kur.isAfterLast()){
            String[] sebarisData = new String[jumlahField];

            for(int i = 0; i < sebarisData.length; i++) {
                sebarisData[i] = kur.getString(i);
            }
            data.add(new StrukturData(sebarisData));

            kur.moveToNext();
        }
        return data;
    }
    public StrukturData dapatkanData(String namaTabel, String namaField, String value) {
        Cursor kur = db.rawQuery("select * from " + namaTabel + " where " + namaField + " = " + value, null);
        kur.moveToFirst();

        int jumlahField = kur.getColumnCount();
        String[] baris = new String[jumlahField];

        for(int i = 0; i < jumlahField; i++) {
            baris[i] = kur.getString(i);
        }
        return new StrukturData(baris);
    }
    public void update(String namaTabel, String fieldKriteria, String valueKriteria, String... valueBaru){
        Cursor kur = db.rawQuery("select * from " + namaTabel, null);

        ContentValues val = new ContentValues();

        for(int i = 0; i < valueBaru.length; i++) {
            val.put(kur.getColumnName(i), valueBaru[i]);
        }
        db.update(namaTabel, val, fieldKriteria + " = '" + valueKriteria + "'", null);
    }
    public void hapus(String namaTabel, String field, String value) {
        db.delete(namaTabel, field + " = '" + value + "'", null);
    }
    @Override
    public void onCreate(SQLiteDatabase sqdb) {
        sqdb.execSQL(cont.getResources().getString(R.string.buat_tabelsoal));
        sqdb.execSQL(cont.getResources().getString(R.string.buat_tabelanimasi));

        ContentValues val = new ContentValues();
        val.put("soal", "alat untuk melindungi kepala salah satunya adalah?");
        val.put("A", "Sabuk");
        val.put("B", "Sepatu");
        val.put("C", "Helm");
        val.put("jawaban", "C");
        sqdb.insert(Managementdb.TABEL_SOAL, null, val);

        val = new ContentValues();
        val.put("soal", "K3 kependekan dari?");
        val.put("A", "Kesehatan dan Keselamatan Kerja");
        val.put("B", "Kesehatan Kerja dan Keselamatan");
        val.put("C", "Salah Semua");
        val.put("jawaban", "A");
        sqdb.insert(Managementdb.TABEL_SOAL, null, val);

        val = new ContentValues();
        val.put("soal", "K3 kependekan dari?");
        val.put("A", "Kesehatan dan Keselamatan Kerja");
        val.put("B", "Kesehatan Kerja dan Keselamatan");
        val.put("C", "Salah Semua");
        val.put("jawaban", "A");
        sqdb.insert(Managementdb.TABEL_SOAL, null, val);
    }
    @Override
    public void onUpgrade(SQLiteDatabase sqdb, int i, int i1) {
        sqdb.execSQL(cont.getResources().getString(R.string.hapus_tabel));
        onCreate(sqdb);
    }
    public class StrukturData {
        private String[] data;

        public StrukturData(String[] data) {
            this.data = new String[data.length];

            for (int i = 0; i < data.length; i++) {
                this.data[i] = data[i];
            }
        }
        public void setData(int indexField, String value) {
            this.data[indexField] = value;
        }
        public String dapatkanData(int indexField) {
            return this.data [indexField];
        }
        public int dapatkanJumlahField() {
            return data.length;
        }
        public String toString() {
            return data[1];
        }
    }
}